import { useQuery } from "@tanstack/react-query";
import { Download } from "lucide-react";
import { Button } from "@/components/ui/button";

export function AuditTrail() {
  const { data: auditLogs = [], isLoading } = useQuery({
    queryKey: ["/api/audit-logs"],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const handleExportAuditLog = () => {
    console.log("Exporting audit log...");
    // TODO: Implement audit log export
  };

  const handleViewFullAuditLog = () => {
    console.log("View full audit log...");
    // TODO: Navigate to full audit log view
  };

  const getEventColor = (eventType: string) => {
    switch (eventType) {
      case 'RULE_CREATED':
      case 'RULE_TOGGLED':
        return 'bg-ibm-green';
      case 'POLICY_VIOLATION':
      case 'TRANSACTION_COMPLIANCE_ISSUE':
        return 'bg-ibm-amber';
      case 'POLICY_CREATED':
      case 'POLICY_SIMULATION':
        return 'bg-ibm-purple';
      case 'IDENTITY_VERIFIED':
        return 'bg-ibm-blue';
      default:
        return 'bg-gray-500';
    }
  };

  const formatEventDescription = (log: any) => {
    return log.description || `${log.eventType.replace('_', ' ').toLowerCase()}`;
  };

  const formatTimeAgo = (timestamp: string) => {
    const now = new Date();
    const then = new Date(timestamp);
    const diffMs = now.getTime() - then.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins} minutes ago`;
    if (diffMins < 1440) return `${Math.floor(diffMins / 60)} hours ago`;
    return `${Math.floor(diffMins / 1440)} days ago`;
  };

  if (isLoading) {
    return (
      <div className="bg-ibm-dark border border-gray-700 rounded-xl p-6">
        <div className="animate-pulse">
          <div className="h-6 bg-gray-700 rounded mb-4"></div>
          <div className="space-y-3">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="h-16 bg-gray-800 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-ibm-dark border border-gray-700 rounded-xl p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-white">Audit Trail</h3>
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={handleExportAuditLog}
          className="text-ibm-blue hover:text-blue-400"
        >
          <Download className="w-4 h-4" />
        </Button>
      </div>
      
      <div className="space-y-3">
        {auditLogs.slice(0, 4).map((log: any) => (
          <div key={log.id} className="flex items-start space-x-3 p-3 bg-gray-800 rounded-lg">
            <div className={`flex-shrink-0 w-2 h-2 ${getEventColor(log.eventType)} rounded-full mt-2`}></div>
            <div className="flex-1 min-w-0">
              <p className="text-sm text-white font-medium">
                {log.eventType.replace(/_/g, ' ').replace(/\b\w/g, (l: string) => l.toUpperCase())}
              </p>
              <p className="text-xs text-gray-400 mb-1 truncate">
                {formatEventDescription(log)}
              </p>
              <p className="text-xs text-gray-500">
                {formatTimeAgo(log.createdAt)} • {log.userId || 'System'}
              </p>
            </div>
          </div>
        ))}

        {auditLogs.length === 0 && (
          <div className="text-center py-8 text-gray-400">
            <p>No audit events recorded</p>
          </div>
        )}
      </div>

      <Button 
        onClick={handleViewFullAuditLog}
        variant="secondary"
        className="w-full mt-4 bg-gray-700 hover:bg-gray-600 text-white"
      >
        View Full Audit Log
      </Button>
    </div>
  );
}
