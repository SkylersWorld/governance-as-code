import { useQuery } from "@tanstack/react-query";
import { Check, Key, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";

export function IdentityVerification() {
  const { data: stats, isLoading } = useQuery({
    queryKey: ["/api/identity-stats"],
  });

  if (isLoading) {
    return (
      <div className="bg-ibm-dark border border-gray-700 rounded-xl p-6">
        <div className="animate-pulse">
          <div className="h-6 bg-gray-700 rounded mb-4"></div>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-16 bg-gray-800 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const verificationStats = [
    {
      title: "Identity Proofs",
      subtitle: "One-time verification",
      value: "98.2%",
      icon: Check,
      color: "text-ibm-green",
      bg: "bg-ibm-green"
    },
    {
      title: "Credential Validity", 
      subtitle: "Active credentials",
      value: "45,891",
      icon: Key,
      color: "text-ibm-blue",
      bg: "bg-ibm-blue"
    },
    {
      title: "Pending Reviews",
      subtitle: "Manual verification", 
      value: "1,438",
      icon: Clock,
      color: "text-ibm-amber",
      bg: "bg-ibm-amber"
    }
  ];

  return (
    <div className="bg-ibm-dark border border-gray-700 rounded-xl p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-white">DID Verification</h3>
        <span className="text-xs bg-ibm-green/20 text-ibm-green px-2 py-1 rounded-full">
          47,329 Verified
        </span>
      </div>
      
      <div className="space-y-4">
        {verificationStats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="flex items-center justify-between p-3 bg-gray-800 rounded-lg">
              <div className="flex items-center space-x-3">
                <div className={`w-8 h-8 ${stat.bg} rounded-full flex items-center justify-center`}>
                  <Icon className="text-white text-xs" size={16} />
                </div>
                <div>
                  <p className="text-sm font-medium text-white">{stat.title}</p>
                  <p className="text-xs text-gray-400">{stat.subtitle}</p>
                </div>
              </div>
              <span className={`${stat.color} text-sm font-semibold`}>{stat.value}</span>
            </div>
          );
        })}
      </div>

      <Button className="w-full mt-4 bg-ibm-blue hover:bg-blue-600 text-white">
        View Verification Queue
      </Button>
    </div>
  );
}
