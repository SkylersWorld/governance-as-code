import { Scale3d, ChartLine, Shield, Coins, IdCard, Code, PlayCircle, FileText } from "lucide-react";

const navigationItems = [
  { id: 'dashboard', label: 'Dashboard', icon: ChartLine, active: true },
  { id: 'compliance', label: 'Compliance Engine', icon: Shield },
  { id: 'monetary', label: 'Monetary Policy', icon: Coins },
  { id: 'identity', label: 'DID Verification', icon: IdCard },
  { id: 'rules', label: 'Rules Parser', icon: Code },
  { id: 'simulations', label: 'Simulations', icon: PlayCircle },
  { id: 'audit', label: 'Audit Trail', icon: FileText },
];

export function Sidebar() {
  return (
    <div className="w-64 bg-ibm-dark border-r border-gray-700 flex flex-col">
      {/* Logo and Brand */}
      <div className="p-6 border-b border-gray-700">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-ibm-blue rounded-lg flex items-center justify-center">
            <Scale3d className="text-white text-lg" size={20} />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white">Ma'at</h1>
            <p className="text-xs text-gray-400">Governance as Code</p>
          </div>
        </div>
      </div>
      
      {/* Navigation Menu */}
      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          {navigationItems.map((item) => {
            const Icon = item.icon;
            return (
              <li key={item.id}>
                <a
                  href="#"
                  className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                    item.active
                      ? 'bg-ibm-blue/20 text-ibm-blue'
                      : 'text-gray-300 hover:bg-gray-800'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span>{item.label}</span>
                </a>
              </li>
            );
          })}
        </ul>
      </nav>
      
      {/* User Profile */}
      <div className="p-4 border-t border-gray-700">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-ibm-purple rounded-full flex items-center justify-center">
            <span className="text-white text-sm font-semibold">AB</span>
          </div>
          <div>
            <p className="text-sm font-medium text-white">Athena Biju</p>
            <p className="text-xs text-gray-400">System Architect</p>
          </div>
        </div>
      </div>
    </div>
  );
}
