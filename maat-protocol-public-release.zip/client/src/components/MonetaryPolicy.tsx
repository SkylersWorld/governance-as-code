import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Card } from "@/components/ui/card";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from "chart.js";
import { apiRequest } from "@/lib/api";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

export function MonetaryPolicy() {
  const [targetInflation, setTargetInflation] = useState([2.0]);
  const [supplyElasticity, setSupplyElasticity] = useState([1.2]);
  const [volatilityDamper, setVolatilityDamper] = useState([0.85]);
  const [simulationResults, setSimulationResults] = useState<any>(null);
  
  const queryClient = useQueryClient();

  const { data: policies = [] } = useQuery({
    queryKey: ["/api/monetary-policies"],
  });

  const simulationMutation = useMutation({
    mutationFn: async (policyId: number) => {
      const response = await apiRequest("POST", `/api/monetary-policies/${policyId}/simulate`);
      return response.json();
    },
    onSuccess: (data) => {
      setSimulationResults(data.results);
      queryClient.invalidateQueries({ queryKey: ["/api/monetary-policies"] });
    },
  });

  const handleRunSimulation = () => {
    // For demo, use the first policy or create a temporary one
    const activePolicyId = policies.find((p: any) => p.isActive)?.id || 1;
    simulationMutation.mutate(activePolicyId);
  };

  const chartData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    datasets: [
      {
        label: 'Supply (Billions)',
        data: simulationResults?.projectedSupply || [2.1, 2.2, 2.3, 2.35, 2.38, 2.4],
        borderColor: 'hsl(212, 100%, 54%)',
        backgroundColor: 'hsla(212, 100%, 54%, 0.1)',
        tension: 0.4,
        fill: true,
      },
      {
        label: 'Volatility (%)',
        data: simulationResults?.projectedVolatility || [0.45, 0.32, 0.28, 0.31, 0.26, 0.23],
        borderColor: 'hsl(261, 100%, 62%)',
        backgroundColor: 'hsla(261, 100%, 62%, 0.1)',
        tension: 0.4,
        yAxisID: 'y1',
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        labels: {
          color: '#F4F4F4',
          font: {
            family: 'IBM Plex Sans',
          },
        },
      },
    },
    scales: {
      x: {
        ticks: {
          color: '#F4F4F4',
        },
        grid: {
          color: 'rgba(244, 244, 244, 0.1)',
        },
      },
      y: {
        type: 'linear' as const,
        display: true,
        position: 'left' as const,
        ticks: {
          color: '#F4F4F4',
        },
        grid: {
          color: 'rgba(244, 244, 244, 0.1)',
        },
      },
      y1: {
        type: 'linear' as const,
        display: true,
        position: 'right' as const,
        ticks: {
          color: '#F4F4F4',
        },
        grid: {
          drawOnChartArea: false,
        },
      },
    },
  };

  return (
    <div className="bg-ibm-dark border border-gray-700 rounded-xl p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-white">Monetary Policy Simulator</h3>
        <Button 
          onClick={handleRunSimulation}
          disabled={simulationMutation.isPending}
          className="bg-ibm-blue hover:bg-blue-600 text-white"
        >
          <Play className="w-4 h-4 mr-2" />
          {simulationMutation.isPending ? 'Running...' : 'Run Simulation'}
        </Button>
      </div>
      
      {/* Policy Parameters */}
      <div className="space-y-4 mb-6">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Target Inflation Rate: {targetInflation[0]}%
          </label>
          <Slider
            value={targetInflation}
            onValueChange={setTargetInflation}
            max={5}
            min={0}
            step={0.1}
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Supply Elasticity: {supplyElasticity[0]}x
          </label>
          <Slider
            value={supplyElasticity}
            onValueChange={setSupplyElasticity}
            max={2}
            min={0.1}
            step={0.1}
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Volatility Damper: {volatilityDamper[0]}
          </label>
          <Slider
            value={volatilityDamper}
            onValueChange={setVolatilityDamper}
            max={1}
            min={0}
            step={0.05}
          />
        </div>
      </div>

      {/* Policy Effect Visualization */}
      <Card className="h-48 bg-gray-800 border-gray-600 p-4 mb-4">
        <Line data={chartData} options={chartOptions} />
      </Card>

      {/* Current Policy Status */}
      <div className="grid grid-cols-2 gap-4">
        <div className="text-center">
          <p className="text-2xl font-bold text-ibm-green">$2.4B</p>
          <p className="text-xs text-gray-400">Current Supply</p>
        </div>
        <div className="text-center">
          <p className="text-2xl font-bold text-ibm-blue">0.23%</p>
          <p className="text-xs text-gray-400">Volatility (24h)</p>
        </div>
      </div>
    </div>
  );
}
