import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { apiRequest } from "@/lib/api";

export function RulesParser() {
  const [legalCondition, setLegalCondition] = useState(
    "Transactions exceeding USD 50,000 must undergo enhanced due diligence procedures including source of funds verification and beneficial ownership disclosure."
  );
  const [parsedCode, setParsedCode] = useState("");

  const parseRuleMutation = useMutation({
    mutationFn: async (condition: string) => {
      const response = await apiRequest("POST", "/api/parse-rule", {
        legalCondition: condition,
      });
      return response.json();
    },
    onSuccess: (data) => {
      setParsedCode(data.parsedCode);
    },
  });

  const handleParseRule = () => {
    if (legalCondition.trim()) {
      parseRuleMutation.mutate(legalCondition);
    }
  };

  const handleTestRule = () => {
    console.log("Testing rule logic...");
    // TODO: Implement rule testing functionality
  };

  return (
    <div className="bg-ibm-dark border border-gray-700 rounded-xl p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-white">Rules Parser</h3>
        <Button variant="ghost" size="sm" className="text-ibm-blue hover:text-blue-400">
          <Plus className="w-4 h-4" />
        </Button>
      </div>
      
      {/* Legal Input */}
      <div className="mb-4">
        <label className="block text-sm font-medium text-gray-300 mb-2">
          Legal Condition
        </label>
        <Textarea
          value={legalCondition}
          onChange={(e) => setLegalCondition(e.target.value)}
          className="w-full h-20 bg-gray-800 border border-gray-600 rounded-lg text-white text-sm resize-none focus:ring-2 focus:ring-ibm-blue focus:border-transparent"
          placeholder="Enter legal condition in natural language..."
        />
      </div>

      {/* Parsed Output */}
      <div className="mb-4">
        <label className="block text-sm font-medium text-gray-300 mb-2">
          Executable Code
        </label>
        <Card className="bg-gray-900 border-gray-600 p-3">
          <pre className="text-ibm-green text-xs font-mono whitespace-pre-wrap">
            {parsedCode || `if (transaction.amount > 50000 && transaction.currency === 'USD') {
  return {
    requireEnhancedDueDiligence: true,
    verificationSteps: [
      'SOURCE_OF_FUNDS_VERIFICATION',
      'BENEFICIAL_OWNERSHIP_DISCLOSURE'
    ],
    riskLevel: 'HIGH'
  };
}`}
          </pre>
        </Card>
      </div>

      <div className="flex space-x-2">
        <Button
          onClick={handleParseRule}
          disabled={parseRuleMutation.isPending}
          className="flex-1 bg-ibm-purple hover:bg-purple-600 text-white"
        >
          {parseRuleMutation.isPending ? "Parsing..." : "Parse Rule"}
        </Button>
        <Button
          onClick={handleTestRule}
          variant="secondary"
          className="flex-1 bg-gray-700 hover:bg-gray-600 text-white"
        >
          Test Logic
        </Button>
      </div>
    </div>
  );
}
