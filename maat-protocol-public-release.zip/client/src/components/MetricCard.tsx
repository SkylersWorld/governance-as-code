import { Shield, Coins, IdCard, AlertTriangle, TrendingUp, TrendingDown } from "lucide-react";

interface MetricCardProps {
  title: string;
  value: string;
  change: string;
  icon: 'shield' | 'coins' | 'id-card' | 'alert-triangle';
  color: 'blue' | 'purple' | 'green' | 'red';
}

const iconMap = {
  shield: Shield,
  coins: Coins,
  'id-card': IdCard,
  'alert-triangle': AlertTriangle,
};

const colorMap = {
  blue: {
    bg: 'bg-ibm-blue/20',
    text: 'text-ibm-blue',
    change: 'bg-ibm-green/20 text-ibm-green'
  },
  purple: {
    bg: 'bg-ibm-purple/20',
    text: 'text-ibm-purple',
    change: 'bg-ibm-amber/20 text-ibm-amber'
  },
  green: {
    bg: 'bg-ibm-green/20',
    text: 'text-ibm-green',
    change: 'bg-ibm-green/20 text-ibm-green'
  },
  red: {
    bg: 'bg-ibm-red/20',
    text: 'text-ibm-red',
    change: 'bg-ibm-red/20 text-ibm-red'
  }
};

export function MetricCard({ title, value, change, icon, color }: MetricCardProps) {
  const Icon = iconMap[icon];
  const colors = colorMap[color];
  const isPositive = change.startsWith('+');
  const isNegative = change.startsWith('-');

  return (
    <div className="bg-ibm-dark border border-gray-700 rounded-xl p-6">
      <div className="flex items-center justify-between mb-4">
        <div className={`w-12 h-12 ${colors.bg} rounded-lg flex items-center justify-center`}>
          <Icon className={`${colors.text} text-xl`} size={24} />
        </div>
        <span className={`text-xs px-2 py-1 rounded-full ${colors.change}`}>
          {isPositive && <TrendingUp className="inline w-3 h-3 mr-1" />}
          {isNegative && <TrendingDown className="inline w-3 h-3 mr-1" />}
          {change}
        </span>
      </div>
      <h3 className="text-2xl font-bold text-white mb-1">{value}</h3>
      <p className="text-gray-400 text-sm">{title}</p>
    </div>
  );
}
