import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { apiRequest } from "@/lib/api";
import { ComplianceRule } from "@shared/schema";

export function ComplianceEngine() {
  const queryClient = useQueryClient();
  
  const { data: rules = [], isLoading } = useQuery({
    queryKey: ["/api/compliance-rules"],
  });

  const toggleRuleMutation = useMutation({
    mutationFn: async (ruleId: number) => {
      const response = await apiRequest("PATCH", `/api/compliance-rules/${ruleId}/toggle`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/compliance-rules"] });
    },
  });

  const handleToggleRule = (ruleId: number) => {
    toggleRuleMutation.mutate(ruleId);
  };

  if (isLoading) {
    return (
      <div className="bg-ibm-dark border border-gray-700 rounded-xl p-6">
        <div className="animate-pulse">
          <div className="h-6 bg-gray-700 rounded mb-4"></div>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-20 bg-gray-800 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-ibm-dark border border-gray-700 rounded-xl p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-white">Compliance Rules Engine</h3>
        <Button variant="ghost" size="sm" className="text-ibm-blue hover:text-blue-400">
          <Settings className="w-4 h-4" />
        </Button>
      </div>
      
      <div className="space-y-4">
        {rules.map((rule: ComplianceRule) => (
          <div key={rule.id} className="border border-gray-700 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-medium text-white">{rule.name}</span>
              <div className="flex items-center space-x-2">
                <span className={`text-xs px-2 py-1 rounded-full ${
                  rule.isActive 
                    ? 'bg-ibm-green/20 text-ibm-green' 
                    : 'bg-gray-700 text-gray-400'
                }`}>
                  {rule.isActive ? 'Active' : 'Inactive'}
                </span>
                <Switch
                  checked={rule.isActive}
                  onCheckedChange={() => handleToggleRule(rule.id)}
                  disabled={toggleRuleMutation.isPending}
                />
              </div>
            </div>
            <div className="text-xs text-gray-400 mb-2">
              {rule.description}
            </div>
            <div className="text-xs font-mono text-gray-500 bg-gray-900 p-2 rounded">
              {rule.ruleLogic}
            </div>
          </div>
        ))}

        {rules.length === 0 && (
          <div className="text-center py-8 text-gray-400">
            <p>No compliance rules configured</p>
            <Button className="mt-4 bg-ibm-blue hover:bg-blue-600">
              Add Rule
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
