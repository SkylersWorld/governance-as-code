import { Sidebar } from "@/components/Sidebar";
import { MetricCard } from "@/components/MetricCard";
import { ComplianceEngine } from "@/components/ComplianceEngine";
import { MonetaryPolicy } from "@/components/MonetaryPolicy";
import { IdentityVerification } from "@/components/IdentityVerification";
import { RulesParser } from "@/components/RulesParser";
import { AuditTrail } from "@/components/AuditTrail";
import { useQuery } from "@tanstack/react-query";
import { Play, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useWebSocket } from "@/hooks/useWebSocket";

export default function Dashboard() {
  const { data: systemStatus, isLoading: statusLoading } = useQuery({
    queryKey: ["/api/system-status"],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const { data: metrics, isLoading: metricsLoading } = useQuery({
    queryKey: ["/api/metrics"],
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  // WebSocket connection for real-time updates
  useWebSocket();

  const isLive = systemStatus?.isLive ?? false;

  const handleRunSystemTest = () => {
    // TODO: Implement system test functionality
    console.log("Running system test...");
  };

  if (statusLoading || metricsLoading) {
    return (
      <div className="h-screen flex items-center justify-center bg-ibm-dark">
        <Loader2 className="h-8 w-8 animate-spin text-ibm-blue" />
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-ibm-dark text-ibm-light">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-ibm-dark border-b border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-white">Institutional Dashboard</h2>
              <p className="text-gray-400 mt-1">Real-time compliance monitoring and policy testing</p>
            </div>
            <div className="flex items-center space-x-4">
              <div className={`flex items-center space-x-2 px-3 py-2 rounded-lg ${
                isLive ? 'bg-ibm-green/20' : 'bg-ibm-red/20'
              }`}>
                <div className={`w-2 h-2 rounded-full animate-pulse ${
                  isLive ? 'bg-ibm-green' : 'bg-ibm-red'
                }`}></div>
                <span className={`text-sm font-medium ${
                  isLive ? 'text-ibm-green' : 'text-ibm-red'
                }`}>
                  {isLive ? 'System Live' : 'System Offline'}
                </span>
              </div>
              <Button 
                onClick={handleRunSystemTest}
                className="bg-ibm-blue hover:bg-blue-600 text-white"
              >
                <Play className="w-4 h-4 mr-2" />
                Run Test
              </Button>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 p-6 bg-gray-900 overflow-y-auto">
          {/* Metrics Grid */}
          <div className="grid grid-cols-1 xl:grid-cols-4 gap-6 mb-8">
            <MetricCard
              title="Compliance Rate" 
              value="98.7%"
              change="+2.3%"
              icon="shield"
              color="blue"
            />
            <MetricCard
              title="Stablecoin Supply"
              value="$2.4B"
              change="-0.1%"
              icon="coins"
              color="purple"
            />
            <MetricCard
              title="Verified Identities"
              value="47,329"
              change="+15.2%"
              icon="id-card"
              color="green"
            />
            <MetricCard
              title="Policy Violations"
              value="12"
              change="3 Active"
              icon="alert-triangle"
              color="red"
            />
          </div>

          {/* Main Panels */}
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 mb-8">
            <ComplianceEngine />
            <MonetaryPolicy />
          </div>

          {/* Secondary Panels */}
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
            <IdentityVerification />
            <RulesParser />
            <AuditTrail />
          </div>
        </main>
      </div>
    </div>
  );
}
