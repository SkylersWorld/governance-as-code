import { 
  complianceRules, 
  monetaryPolicies, 
  identityVerifications, 
  transactions, 
  auditLogs, 
  policySimulations, 
  systemMetrics,
  type ComplianceRule,
  type InsertComplianceRule,
  type MonetaryPolicy,
  type InsertMonetaryPolicy,
  type IdentityVerification,
  type InsertIdentityVerification,
  type Transaction,
  type InsertTransaction,
  type AuditLog,
  type InsertAuditLog,
  type PolicySimulation,
  type InsertPolicySimulation,
  type SystemMetric,
  type InsertSystemMetric
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // Compliance Rules
  getComplianceRules(): Promise<ComplianceRule[]>;
  createComplianceRule(rule: InsertComplianceRule): Promise<ComplianceRule>;
  toggleComplianceRule(id: number): Promise<ComplianceRule>;
  
  // Monetary Policies
  getMonetaryPolicies(): Promise<MonetaryPolicy[]>;
  getMonetaryPolicy(id: number): Promise<MonetaryPolicy | undefined>;
  createMonetaryPolicy(policy: InsertMonetaryPolicy): Promise<MonetaryPolicy>;
  
  // Policy Simulations
  createPolicySimulation(simulation: InsertPolicySimulation): Promise<PolicySimulation>;
  updatePolicySimulation(id: number, updates: Partial<PolicySimulation>): Promise<PolicySimulation>;
  
  // Identity Verification
  getIdentityVerifications(): Promise<IdentityVerification[]>;
  getIdentityStats(): Promise<any>;
  
  // Transactions
  getTransactions(): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  processTransactionCompliance(transaction: InsertTransaction): Promise<{ status: string; flags: any }>;
  
  // Audit Logs
  getAuditLogs(limit?: number): Promise<AuditLog[]>;
  createAuditLog(log: InsertAuditLog): Promise<AuditLog>;
  
  // System Metrics
  getSystemMetrics(): Promise<SystemMetric[]>;
  
  // Rules Parser
  parseRule(legalCondition: string): Promise<string>;
}

export class DatabaseStorage implements IStorage {
  // Compliance Rules
  async getComplianceRules(): Promise<ComplianceRule[]> {
    return await db.select().from(complianceRules).orderBy(desc(complianceRules.createdAt));
  }

  async createComplianceRule(rule: InsertComplianceRule): Promise<ComplianceRule> {
    const [created] = await db.insert(complianceRules).values(rule).returning();
    return created;
  }

  async toggleComplianceRule(id: number): Promise<ComplianceRule> {
    const [existing] = await db.select().from(complianceRules).where(eq(complianceRules.id, id));
    if (!existing) throw new Error("Rule not found");
    
    const [updated] = await db
      .update(complianceRules)
      .set({ isActive: !existing.isActive, updatedAt: new Date() })
      .where(eq(complianceRules.id, id))
      .returning();
    return updated;
  }

  // Monetary Policies
  async getMonetaryPolicies(): Promise<MonetaryPolicy[]> {
    return await db.select().from(monetaryPolicies).orderBy(desc(monetaryPolicies.createdAt));
  }

  async getMonetaryPolicy(id: number): Promise<MonetaryPolicy | undefined> {
    const [policy] = await db.select().from(monetaryPolicies).where(eq(monetaryPolicies.id, id));
    return policy;
  }

  async createMonetaryPolicy(policy: InsertMonetaryPolicy): Promise<MonetaryPolicy> {
    const [created] = await db.insert(monetaryPolicies).values(policy).returning();
    return created;
  }

  // Policy Simulations
  async createPolicySimulation(simulation: InsertPolicySimulation): Promise<PolicySimulation> {
    const [created] = await db.insert(policySimulations).values(simulation).returning();
    return created;
  }

  async updatePolicySimulation(id: number, updates: Partial<PolicySimulation>): Promise<PolicySimulation> {
    const [updated] = await db
      .update(policySimulations)
      .set({ ...updates, completedAt: updates.status === 'COMPLETED' ? new Date() : undefined })
      .where(eq(policySimulations.id, id))
      .returning();
    return updated;
  }

  // Identity Verification
  async getIdentityVerifications(): Promise<IdentityVerification[]> {
    return await db.select().from(identityVerifications).orderBy(desc(identityVerifications.createdAt));
  }

  async getIdentityStats(): Promise<any> {
    const verifications = await this.getIdentityVerifications();
    const verified = verifications.filter(v => v.status === 'VERIFIED').length;
    const pending = verifications.filter(v => v.status === 'PENDING').length;
    
    return {
      totalVerified: verified,
      totalPending: pending,
      verificationRate: verifications.length > 0 ? (verified / verifications.length * 100).toFixed(1) : '0.0'
    };
  }

  // Transactions
  async getTransactions(): Promise<Transaction[]> {
    return await db.select().from(transactions).orderBy(desc(transactions.processedAt));
  }

  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const [created] = await db.insert(transactions).values(transaction).returning();
    return created;
  }

  async processTransactionCompliance(transaction: InsertTransaction): Promise<{ status: string; flags: any }> {
    const rules = await this.getComplianceRules();
    const activeRules = rules.filter(r => r.isActive);
    
    let status = 'PROCESSED';
    const flags: any = {};
    
    // Simple compliance logic
    const amount = parseFloat(transaction.amount);
    
    for (const rule of activeRules) {
      if (rule.ruleType === 'AML' && amount > 50000) {
        status = 'FLAGGED';
        flags.aml = 'Enhanced due diligence required';
      }
      
      if (rule.ruleType === 'CAPITAL_ADEQUACY' && amount > 100000) {
        status = 'BLOCKED';
        flags.capitalAdequacy = 'Transaction exceeds capital limits';
        break;
      }
    }
    
    return { status, flags };
  }

  // Audit Logs
  async getAuditLogs(limit: number = 50): Promise<AuditLog[]> {
    return await db.select().from(auditLogs).orderBy(desc(auditLogs.createdAt)).limit(limit);
  }

  async createAuditLog(log: InsertAuditLog): Promise<AuditLog> {
    const [created] = await db.insert(auditLogs).values(log).returning();
    return created;
  }

  // System Metrics
  async getSystemMetrics(): Promise<SystemMetric[]> {
    return await db.select().from(systemMetrics).orderBy(desc(systemMetrics.timestamp));
  }

  // Rules Parser
  async parseRule(legalCondition: string): Promise<string> {
    // Simple rule parsing logic (in production, this would use NLP/AI)
    let code = '';
    
    if (legalCondition.toLowerCase().includes('50,000') || legalCondition.toLowerCase().includes('50000')) {
      code = `if (transaction.amount > 50000 && transaction.currency === 'USD') {
  return {
    requireEnhancedDueDiligence: true,
    verificationSteps: [
      'SOURCE_OF_FUNDS_VERIFICATION',
      'BENEFICIAL_OWNERSHIP_DISCLOSURE'
    ],
    riskLevel: 'HIGH'
  };
}`;
    } else if (legalCondition.toLowerCase().includes('kyc') || legalCondition.toLowerCase().includes('identity')) {
      code = `if (!user.identityVerified || user.verificationExpired) {
  return {
    requireIdentityVerification: true,
    blockedActions: ['TRANSFER', 'WITHDRAWAL'],
    riskLevel: 'MEDIUM'
  };
}`;
    } else {
      code = `// Parsed from: ${legalCondition.substring(0, 50)}...
if (transaction.riskScore > 0.7) {
  return {
    requireManualReview: true,
    riskLevel: 'HIGH',
    flags: ['SUSPICIOUS_PATTERN']
  };
}`;
    }
    
    return code;
  }
}

export const storage = new DatabaseStorage();