import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer } from "ws";
import { storage } from "./storage";
import { 
  insertComplianceRuleSchema, 
  insertMonetaryPolicySchema,
  insertIdentityVerificationSchema,
  insertTransactionSchema,
  insertAuditLogSchema,
  insertPolicySimulationSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // WebSocket server for real-time updates on separate port
  const wss = new WebSocketServer({ port: 5001 });
  
  wss.on('connection', (ws) => {
    console.log('Client connected to WebSocket');
    
    ws.on('close', () => {
      console.log('Client disconnected from WebSocket');
    });
  });

  // Broadcast function for real-time updates
  const broadcast = (data: any) => {
    wss.clients.forEach((client) => {
      if (client.readyState === 1) { // WebSocket.OPEN
        client.send(JSON.stringify(data));
      }
    });
  };

  // System Metrics
  app.get("/api/metrics", async (req, res) => {
    try {
      const metrics = await storage.getSystemMetrics();
      res.json(metrics);
    } catch (error) {
      console.error("Error fetching metrics:", error);
      res.status(500).json({ message: "Failed to fetch metrics" });
    }
  });

  // Compliance Rules
  app.get("/api/compliance-rules", async (req, res) => {
    try {
      const rules = await storage.getComplianceRules();
      res.json(rules);
    } catch (error) {
      console.error("Error fetching compliance rules:", error);
      res.status(500).json({ message: "Failed to fetch compliance rules" });
    }
  });

  app.post("/api/compliance-rules", async (req, res) => {
    try {
      const validatedData = insertComplianceRuleSchema.parse(req.body);
      const rule = await storage.createComplianceRule(validatedData);
      
      // Log audit event
      await storage.createAuditLog({
        eventType: "RULE_CREATED",
        description: `New compliance rule created: ${rule.name}`,
        entityType: "RULE",
        entityId: rule.id.toString(),
        metadata: { ruleType: rule.ruleType }
      });

      broadcast({ type: 'RULE_CREATED', data: rule });
      res.json(rule);
    } catch (error) {
      console.error("Error creating compliance rule:", error);
      res.status(500).json({ message: "Failed to create compliance rule" });
    }
  });

  app.patch("/api/compliance-rules/:id/toggle", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const rule = await storage.toggleComplianceRule(id);
      
      await storage.createAuditLog({
        eventType: "RULE_TOGGLED",
        description: `Compliance rule ${rule.isActive ? 'activated' : 'deactivated'}: ${rule.name}`,
        entityType: "RULE",
        entityId: rule.id.toString(),
        metadata: { isActive: rule.isActive }
      });

      broadcast({ type: 'RULE_TOGGLED', data: rule });
      res.json(rule);
    } catch (error) {
      console.error("Error toggling compliance rule:", error);
      res.status(500).json({ message: "Failed to toggle compliance rule" });
    }
  });

  // Monetary Policy
  app.get("/api/monetary-policies", async (req, res) => {
    try {
      const policies = await storage.getMonetaryPolicies();
      res.json(policies);
    } catch (error) {
      console.error("Error fetching monetary policies:", error);
      res.status(500).json({ message: "Failed to fetch monetary policies" });
    }
  });

  app.post("/api/monetary-policies", async (req, res) => {
    try {
      const validatedData = insertMonetaryPolicySchema.parse(req.body);
      const policy = await storage.createMonetaryPolicy(validatedData);
      
      await storage.createAuditLog({
        eventType: "POLICY_CREATED",
        description: `New monetary policy created: ${policy.name}`,
        entityType: "POLICY",
        entityId: policy.id.toString(),
        metadata: { 
          targetInflationRate: policy.targetInflationRate,
          supplyElasticity: policy.supplyElasticity 
        }
      });

      broadcast({ type: 'POLICY_CREATED', data: policy });
      res.json(policy);
    } catch (error) {
      console.error("Error creating monetary policy:", error);
      res.status(500).json({ message: "Failed to create monetary policy" });
    }
  });

  app.post("/api/monetary-policies/:id/simulate", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const policy = await storage.getMonetaryPolicy(id);
      if (!policy) {
        return res.status(404).json({ message: "Policy not found" });
      }

      // Create simulation record
      const simulation = await storage.createPolicySimulation({
        name: `Simulation for ${policy.name}`,
        parameters: {
          policyId: id,
          targetInflationRate: policy.targetInflationRate,
          supplyElasticity: policy.supplyElasticity,
          volatilityDamper: policy.volatilityDamper
        },
        status: "RUNNING"
      });

      // Simulate policy effects (simplified calculation)
      const results = {
        projectedSupply: Array.from({ length: 6 }, (_, i) => {
          const baseSupply = parseFloat(policy.currentSupply);
          const growth = parseFloat(policy.supplyElasticity) * (1 + i * 0.1);
          return (baseSupply * growth).toFixed(2);
        }),
        projectedVolatility: Array.from({ length: 6 }, (_, i) => {
          const baseDamper = parseFloat(policy.volatilityDamper);
          return (0.5 * baseDamper * (1 - i * 0.05)).toFixed(3);
        }),
        riskAssessment: "LOW",
        complianceScore: 0.98
      };

      // Update simulation with results
      await storage.updatePolicySimulation(simulation.id, {
        results,
        status: "COMPLETED"
      });

      await storage.createAuditLog({
        eventType: "POLICY_SIMULATION",
        description: `Policy simulation completed for ${policy.name}`,
        entityType: "POLICY",
        entityId: policy.id.toString(),
        metadata: { simulationId: simulation.id, riskAssessment: results.riskAssessment }
      });

      broadcast({ type: 'SIMULATION_COMPLETED', data: { simulation, results } });
      res.json({ simulation, results });
    } catch (error) {
      console.error("Error running policy simulation:", error);
      res.status(500).json({ message: "Failed to run policy simulation" });
    }
  });

  // Identity Verification
  app.get("/api/identity-verifications", async (req, res) => {
    try {
      const verifications = await storage.getIdentityVerifications();
      res.json(verifications);
    } catch (error) {
      console.error("Error fetching identity verifications:", error);
      res.status(500).json({ message: "Failed to fetch identity verifications" });
    }
  });

  app.get("/api/identity-stats", async (req, res) => {
    try {
      const stats = await storage.getIdentityStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching identity stats:", error);
      res.status(500).json({ message: "Failed to fetch identity stats" });
    }
  });

  // Transactions
  app.get("/api/transactions", async (req, res) => {
    try {
      const transactions = await storage.getTransactions();
      res.json(transactions);
    } catch (error) {
      console.error("Error fetching transactions:", error);
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  app.post("/api/transactions", async (req, res) => {
    try {
      const validatedData = insertTransactionSchema.parse(req.body);
      
      // Process transaction through compliance engine
      const complianceResult = await storage.processTransactionCompliance(validatedData);
      
      const transaction = await storage.createTransaction({
        ...validatedData,
        status: complianceResult.status,
        complianceFlags: complianceResult.flags
      });

      if (complianceResult.status === 'FLAGGED' || complianceResult.status === 'BLOCKED') {
        await storage.createAuditLog({
          eventType: "TRANSACTION_COMPLIANCE_ISSUE",
          description: `Transaction ${transaction.transactionId} ${complianceResult.status.toLowerCase()}`,
          entityType: "TRANSACTION",
          entityId: transaction.id.toString(),
          metadata: { 
            amount: transaction.amount, 
            flags: complianceResult.flags 
          }
        });
      }

      broadcast({ type: 'TRANSACTION_PROCESSED', data: transaction });
      res.json(transaction);
    } catch (error) {
      console.error("Error processing transaction:", error);
      res.status(500).json({ message: "Failed to process transaction" });
    }
  });

  // Rules Parser
  app.post("/api/parse-rule", async (req, res) => {
    try {
      const { legalCondition } = req.body;
      
      if (!legalCondition) {
        return res.status(400).json({ message: "Legal condition is required" });
      }

      // Simple rule parsing logic (in production, this would be more sophisticated)
      const parsedCode = await storage.parseRule(legalCondition);
      
      await storage.createAuditLog({
        eventType: "RULE_PARSED",
        description: "Legal condition parsed to executable code",
        metadata: { 
          legalCondition: legalCondition.substring(0, 100),
          codeGenerated: true
        }
      });

      res.json({ parsedCode });
    } catch (error) {
      console.error("Error parsing rule:", error);
      res.status(500).json({ message: "Failed to parse rule" });
    }
  });

  // Audit Trail
  app.get("/api/audit-logs", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const logs = await storage.getAuditLogs(limit);
      res.json(logs);
    } catch (error) {
      console.error("Error fetching audit logs:", error);
      res.status(500).json({ message: "Failed to fetch audit logs" });
    }
  });

  // System Status
  app.get("/api/system-status", async (req, res) => {
    try {
      const status = {
        isLive: true,
        uptime: process.uptime(),
        lastHealthCheck: new Date().toISOString(),
        services: {
          complianceEngine: "ACTIVE",
          monetaryPolicy: "ACTIVE", 
          identityVerification: "ACTIVE",
          auditTrail: "ACTIVE"
        }
      };
      res.json(status);
    } catch (error) {
      console.error("Error fetching system status:", error);
      res.status(500).json({ message: "Failed to fetch system status" });
    }
  });

  return httpServer;
}
