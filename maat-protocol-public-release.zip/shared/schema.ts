import { pgTable, text, serial, integer, boolean, timestamp, decimal, jsonb, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Compliance Rules
export const complianceRules = pgTable("compliance_rules", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  ruleLogic: text("rule_logic").notNull(), // The actual code/logic
  legalCondition: text("legal_condition").notNull(), // Natural language description
  isActive: boolean("is_active").default(true),
  ruleType: text("rule_type").notNull(), // AML, JURISDICTIONAL, CAPITAL_ADEQUACY
  threshold: decimal("threshold"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Monetary Policy Configurations
export const monetaryPolicies = pgTable("monetary_policies", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  targetInflationRate: decimal("target_inflation_rate").notNull(),
  supplyElasticity: decimal("supply_elasticity").notNull(),
  volatilityDamper: decimal("volatility_damper").notNull(),
  currentSupply: decimal("current_supply").notNull(),
  isActive: boolean("is_active").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Identity Verifications
export const identityVerifications = pgTable("identity_verifications", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  verificationType: text("verification_type").notNull(), // IDENTITY_PROOF, CREDENTIAL_VALIDITY
  status: text("status").notNull(), // VERIFIED, PENDING, REJECTED
  verificationData: jsonb("verification_data"),
  verifiedAt: timestamp("verified_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Transaction Monitoring
export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  transactionId: text("transaction_id").notNull().unique(),
  amount: decimal("amount").notNull(),
  currency: text("currency").notNull(),
  fromAddress: text("from_address").notNull(),
  toAddress: text("to_address").notNull(),
  status: text("status").notNull(), // PROCESSED, FLAGGED, BLOCKED
  complianceFlags: jsonb("compliance_flags"),
  processedAt: timestamp("processed_at").defaultNow(),
});

// Audit Trail
export const auditLogs = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  eventType: text("event_type").notNull(),
  description: text("description").notNull(),
  userId: text("user_id"),
  entityType: text("entity_type"), // RULE, POLICY, TRANSACTION, IDENTITY
  entityId: text("entity_id"),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Policy Simulations
export const policySimulations = pgTable("policy_simulations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  parameters: jsonb("parameters").notNull(),
  results: jsonb("results"),
  status: text("status").notNull(), // RUNNING, COMPLETED, FAILED
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

// System Metrics
export const systemMetrics = pgTable("system_metrics", {
  id: serial("id").primaryKey(),
  metricType: text("metric_type").notNull(), // COMPLIANCE_RATE, STABLECOIN_SUPPLY, VERIFIED_IDENTITIES, POLICY_VIOLATIONS
  value: decimal("value").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

// Schemas
export const insertComplianceRuleSchema = createInsertSchema(complianceRules).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertMonetaryPolicySchema = createInsertSchema(monetaryPolicies).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertIdentityVerificationSchema = createInsertSchema(identityVerifications).omit({
  id: true,
  verifiedAt: true,
  createdAt: true,
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  processedAt: true,
});

export const insertAuditLogSchema = createInsertSchema(auditLogs).omit({
  id: true,
  createdAt: true,
});

export const insertPolicySimulationSchema = createInsertSchema(policySimulations).omit({
  id: true,
  createdAt: true,
  completedAt: true,
});

export const insertSystemMetricSchema = createInsertSchema(systemMetrics).omit({
  id: true,
  timestamp: true,
});

// Types
export type ComplianceRule = typeof complianceRules.$inferSelect;
export type InsertComplianceRule = z.infer<typeof insertComplianceRuleSchema>;

export type MonetaryPolicy = typeof monetaryPolicies.$inferSelect;
export type InsertMonetaryPolicy = z.infer<typeof insertMonetaryPolicySchema>;

export type IdentityVerification = typeof identityVerifications.$inferSelect;
export type InsertIdentityVerification = z.infer<typeof insertIdentityVerificationSchema>;

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;

export type AuditLog = typeof auditLogs.$inferSelect;
export type InsertAuditLog = z.infer<typeof insertAuditLogSchema>;

export type PolicySimulation = typeof policySimulations.$inferSelect;
export type InsertPolicySimulation = z.infer<typeof insertPolicySimulationSchema>;

export type SystemMetric = typeof systemMetrics.$inferSelect;
export type InsertSystemMetric = z.infer<typeof insertSystemMetricSchema>;
