CREATE TABLE "audit_logs" (
	"id" serial PRIMARY KEY NOT NULL,
	"event_type" text NOT NULL,
	"description" text NOT NULL,
	"user_id" text,
	"entity_type" text,
	"entity_id" text,
	"metadata" jsonb,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "compliance_rules" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"description" text NOT NULL,
	"rule_logic" text NOT NULL,
	"legal_condition" text NOT NULL,
	"is_active" boolean DEFAULT true,
	"rule_type" text NOT NULL,
	"threshold" numeric,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "identity_verifications" (
	"id" serial PRIMARY KEY NOT NULL,
	"user_id" text NOT NULL,
	"verification_type" text NOT NULL,
	"status" text NOT NULL,
	"verification_data" jsonb,
	"verified_at" timestamp,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "monetary_policies" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"target_inflation_rate" numeric NOT NULL,
	"supply_elasticity" numeric NOT NULL,
	"volatility_damper" numeric NOT NULL,
	"current_supply" numeric NOT NULL,
	"is_active" boolean DEFAULT false,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "policy_simulations" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"parameters" jsonb NOT NULL,
	"results" jsonb,
	"status" text NOT NULL,
	"created_at" timestamp DEFAULT now(),
	"completed_at" timestamp
);
--> statement-breakpoint
CREATE TABLE "system_metrics" (
	"id" serial PRIMARY KEY NOT NULL,
	"metric_type" text NOT NULL,
	"value" numeric NOT NULL,
	"timestamp" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "transactions" (
	"id" serial PRIMARY KEY NOT NULL,
	"transaction_id" text NOT NULL,
	"amount" numeric NOT NULL,
	"currency" text NOT NULL,
	"from_address" text NOT NULL,
	"to_address" text NOT NULL,
	"status" text NOT NULL,
	"compliance_flags" jsonb,
	"processed_at" timestamp DEFAULT now(),
	CONSTRAINT "transactions_transaction_id_unique" UNIQUE("transaction_id")
);
